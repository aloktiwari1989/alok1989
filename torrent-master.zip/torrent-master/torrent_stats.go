package torrent

type TorrentStats struct {
	ConnStats // Aggregates stats over all connections past and present.
}
